// write by
// RUI, CHEN  1809853Z-I011-0017

#include <GL\glew.h>
#include <GLFW\glfw3.h>
#include <string>
#include <iostream>
#include <fstream>
#include <cmath>
#include <stack>
#include <glm\glm.hpp>
#include <glm\gtc\type_ptr.hpp> // glm::value_ptr
#include <glm\gtc\matrix_transform.hpp> // glm::translate, glm::rotate, glm::scale, glm::perspective
#include "Sphere.h"
#include "Torus.h"
#include "Utils.h"
using namespace std;

#define numVAOs 1
#define numVBOs 8

float toRadians(float degrees) { return (degrees * 2.0f * 3.14159f) / 360.0f; }
float cameraX, cameraY, cameraZ;
int viewMode=10;//user control the view mode
int lookCenter = 0;//look at center
float depthParam=0.0f;// user control to zoom in or zoom out
glm::vec3 backgroundRotationDirection;//background rotation direction
glm::vec3 center = glm::vec3(0.0f, 0.0f, 0.0f);//position of center

GLuint renderingProgram;
GLuint vao[numVAOs];
GLuint vbo[numVBOs];

// variable allocation for display
GLuint mvLoc, projLoc, nLoc;
int width, height;
float aspect;
glm::mat4 pMat, vMat, mMat, mvMat, invTrMat, lookAtMat;
double currentTime; //current time, updated in the outmost while loop
int RATE = 2;//control the rotation speed
float ellipseParamY = 5.0f; //planet rotation parameter of y-axis
stack<glm::mat4> mvStack;

//light parameter
GLuint globalAmbLoc, ambLoc, diffLoc, specLoc, posLoc, mambLoc, mdiffLoc, mspecLoc, mshiLoc,lightEnableLoc;
glm::vec3 currentLightPos, transformed;
float lightPos[3];
int lightEnable = 2;

Sphere mySphere = Sphere(48);
Torus myTorus(1.5f, 0.3f, 48);
int mySphereVertices = mySphere.getNumVertices();
int mySphereIndices = mySphere.getNumIndices();

///textures
GLuint sunTexture,mercuryTexture,venusTexture, earthTexture, moonTexture,marsTexture,jupiterTexture,saturnTexture,uranusTexture,neptuneTexture,plutoTexture, backgroundTexture;

// white light
float globalAmbient[4] = { 0.03f, 0.03f, 0.03f, 1.0f };
float lightAmbient[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
float lightDiffuse[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
float lightSpecular[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

// silver material
float* matAmb = Utils::silverAmbient();
float* matDif = Utils::silverDiffuse();
float* matSpe = Utils::silverSpecular();
float matShi = Utils::silverShininess();

void installLights(glm::mat4 vMatrix) {
	transformed = glm::vec3(vMatrix * glm::vec4(currentLightPos, 1.0));
	lightPos[0] = transformed.x;
	lightPos[1] = transformed.y;
	lightPos[2] = transformed.z;

	// get the locations of the light and material fields in the shader
	globalAmbLoc = glGetUniformLocation(renderingProgram, "globalAmbient");
	ambLoc = glGetUniformLocation(renderingProgram, "light.ambient");
	diffLoc = glGetUniformLocation(renderingProgram, "light.diffuse");
	specLoc = glGetUniformLocation(renderingProgram, "light.specular");
	posLoc = glGetUniformLocation(renderingProgram, "light.position");
	mambLoc = glGetUniformLocation(renderingProgram, "material.ambient");
	mdiffLoc = glGetUniformLocation(renderingProgram, "material.diffuse");
	mspecLoc = glGetUniformLocation(renderingProgram, "material.specular");
	mshiLoc = glGetUniformLocation(renderingProgram, "material.shininess");
	lightEnableLoc = glGetUniformLocation(renderingProgram, "lightEnable");

	//  set the uniform light and material values in the shader
	glProgramUniform4fv(renderingProgram, globalAmbLoc, 1, globalAmbient);
	glProgramUniform4fv(renderingProgram, ambLoc, 1, lightAmbient);
	glProgramUniform4fv(renderingProgram, diffLoc, 1, lightDiffuse);
	glProgramUniform4fv(renderingProgram, specLoc, 1, lightSpecular);
	glProgramUniform3fv(renderingProgram, posLoc, 1, lightPos);
	glProgramUniform4fv(renderingProgram, mambLoc, 1, matAmb);
	glProgramUniform4fv(renderingProgram, mdiffLoc, 1, matDif);
	glProgramUniform4fv(renderingProgram, mspecLoc, 1, matSpe);
	glProgramUniform1f(renderingProgram, mshiLoc, matShi);
	glProgramUniform1i(renderingProgram, lightEnableLoc, lightEnable);
}


void setupVertices(void) {

	glGenVertexArrays(1, vao);
	glBindVertexArray(vao[0]);
	glGenBuffers(numVBOs, vbo);

	//sphere
	std::vector<int> ind = mySphere.getIndices();
	std::vector<glm::vec3> vert = mySphere.getVertices();
	std::vector<glm::vec2> tex = mySphere.getTexCoords();
	std::vector<glm::vec3> norm = mySphere.getNormals();
	std::vector<float> pvalues;
	std::vector<float> tvalues;
	std::vector<float> nvalues;

	for (int i = 0; i < mySphereVertices; i++) {
		pvalues.push_back(vert[i].x);
		pvalues.push_back(vert[i].y);
		pvalues.push_back(vert[i].z);
		tvalues.push_back(tex[i].s);
		tvalues.push_back(tex[i].t);
		nvalues.push_back(norm[i].x);
		nvalues.push_back(norm[i].y);
		nvalues.push_back(norm[i].z);
	}

	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, pvalues.size() * 4, &pvalues[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, tvalues.size() * 4, &tvalues[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
	glBufferData(GL_ARRAY_BUFFER, nvalues.size() * 4, &nvalues[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo[3]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, ind.size() * 4, &ind[0], GL_STATIC_DRAW);

	//Torus
	std::vector<float> pvaluesTorus;
	std::vector<float> tvaluesTorus;
	std::vector<float> nvaluesTorus;
	std::vector<int> indTorus = myTorus.getIndices();
	std::vector<glm::vec3> vertTorus = myTorus.getVertices();
	std::vector<glm::vec2> texTorus = myTorus.getTexCoords();
	std::vector<glm::vec3> normTorus = myTorus.getNormals();

	for (int i = 0; i < myTorus.getNumVertices(); i++) {
		pvaluesTorus.push_back(vertTorus[i].x);
		pvaluesTorus.push_back(vertTorus[i].y);
		pvaluesTorus.push_back(vertTorus[i].z);
		tvaluesTorus.push_back(texTorus[i].s);
		tvaluesTorus.push_back(texTorus[i].t);
		nvaluesTorus.push_back(normTorus[i].x);
		nvaluesTorus.push_back(normTorus[i].y);
		nvaluesTorus.push_back(normTorus[i].z);
	}

	glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
	glBufferData(GL_ARRAY_BUFFER, pvaluesTorus.size() * 4, &pvaluesTorus[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
	glBufferData(GL_ARRAY_BUFFER, tvaluesTorus.size() * 4, &tvaluesTorus[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
	glBufferData(GL_ARRAY_BUFFER, nvaluesTorus.size() * 4, &nvaluesTorus[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo[7]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indTorus.size() * 4, &indTorus[0], GL_STATIC_DRAW);

}

void init(GLFWwindow* window) {
	renderingProgram = Utils::createShaderProgram("vertShader.glsl", "fragShader.glsl");

	glfwGetFramebufferSize(window, &width, &height);
	aspect = (float)width / (float)height;
	pMat = glm::perspective(1.0472f, aspect, 0.1f, 1000.0f);
	cameraX = 0.0f; cameraY = 0.0f; cameraZ =50.0f;//camera position initialize
	setupVertices();

	sunTexture = Utils::loadTexture("texture/sun.jpeg");
	mercuryTexture = Utils::loadTexture("texture/mercury.bmp");
	venusTexture = Utils::loadTexture("texture/venus.bmp");
	earthTexture = Utils::loadTexture("texture/earth.bmp");
	marsTexture = Utils::loadTexture("texture/mars.bmp");
	jupiterTexture = Utils::loadTexture("texture/jupiter.bmp");
	saturnTexture = Utils::loadTexture("texture/saturn.bmp");
	uranusTexture = Utils::loadTexture("texture/uranus.bmp");
	neptuneTexture = Utils::loadTexture("texture/neptune.bmp");
	plutoTexture = Utils::loadTexture("texture/pluto.bmp");
	moonTexture = Utils::loadTexture("texture/moon.bmp");
	backgroundTexture = Utils::loadTexture("texture/background.jpg");
}

/// <summary>
/// create a planet
/// </summary>
/// <param name="texture">texture name</param>
/// <param name="rotateSpeed">control the speed of rotation of the sun</param>
/// <param name="selfRotateRate">control the speed of self rotation</param>
/// <param name="selfRotateDirection">self rotate direction</param>
/// <param name="xRotationRadius">control the rotate radius of x axis</param>
/// <param name="yRotationRadius">control the rotate radius of y axis</param>
/// <param name="height">the height from the sun surface</param>
/// <param name="scaleVector">scale vector</param>
/// <param name="tilt">tilt value</param>
/// <param name="tiltDirection">tilt direction</param>
/// <param name="isPushTranslate">pass the translation to next planet</param>
/// <param name="isPopTranslate">remove the previous planet's translation, after using</param>
/// <param name="hasRing">append ring or not</param>
void createPlanet(GLuint texture,double rotateSpeed= 4 ,
				  float selfRotateRate= 12,glm::vec3 selfRotateDirection= glm::vec3(0.0, -1.0, 0.0),
	              float xRotationRadius= 4.0,float yRotationRadius= 4.0,float height=0.0,
				  glm::vec3 scaleVector= glm::vec3(1.0f, 1.0f, 1.0f),
				  float tilt=0.0,glm::vec3 tiltDirection= glm::vec3(0.0, 0.0, 0.0),
				  bool isPushTranslate=false,bool isPopTranslate=false,
				  bool hasRing=false) 
{
	mvStack.push(mvStack.top());

	//Rotation
	mvStack.top() *= glm::translate(glm::mat4(1.0f), glm::vec3(sin((float)(currentTime * rotateSpeed)) * xRotationRadius, height, (float)cos(currentTime * rotateSpeed) * yRotationRadius));
	
	if (isPushTranslate) { mvStack.push(mvStack.top());	} // keep the translate for the next object
	
	mvStack.top() *= rotate(glm::mat4(1.0f), (float)tilt, tiltDirection);   // Tilt
	mvStack.top() *= rotate(glm::mat4(1.0f), (float)currentTime * selfRotateRate, selfRotateDirection);// Self-Rotation
	mvStack.top() *= scale(glm::mat4(1.0f), scaleVector);	// Scaling
	glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvStack.top()));
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
	glEnableVertexAttribArray(1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);

	//light
	invTrMat = glm::transpose(glm::inverse(mvStack.top())); // Transpose of inverse of mv matrix
	glUniformMatrix4fv(nLoc, 1, GL_FALSE, glm::value_ptr(invTrMat));
	glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(2);

	//only enable the front face
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo[3]);
	glDrawElements(GL_TRIANGLES, mySphereIndices, GL_UNSIGNED_INT, 0);
	
	if (isPopTranslate) { mvStack.pop();} //remove the tranlation of previous object
	mvStack.pop();


	//ring of the planet
	if (hasRing) {
		mvStack.push(mvStack.top());

		//Rotation
		mvStack.top() *= glm::translate(glm::mat4(1.0f), glm::vec3(sin((float)(currentTime * rotateSpeed)) * xRotationRadius, height, (float)cos(currentTime * rotateSpeed) * yRotationRadius));

		mvStack.top() *= rotate(glm::mat4(1.0f), (float)tilt, tiltDirection);   // Tilt
		mvStack.top() *= rotate(glm::mat4(1.0f), (float)currentTime * selfRotateRate, selfRotateDirection);// Self-Rotation
		mvStack.top() *= scale(glm::mat4(1.0f), scaleVector);	// Scaling
		mvStack.top() *= scale(glm::mat4(1.0f), glm::vec3(1.0f,0.1f, 1.0f));	// flatting
		glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvStack.top()));
		glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		glEnableVertexAttribArray(1);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture);

		//light
		invTrMat = glm::transpose(glm::inverse(mvStack.top())); // Transpose of inverse of mv matrix
		glUniformMatrix4fv(nLoc, 1, GL_FALSE, glm::value_ptr(invTrMat));
		glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);
		glEnableVertexAttribArray(2);

		//only enable the front face
		glEnable(GL_CULL_FACE);
		glFrontFace(GL_CCW);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo[7]);
		glDrawElements(GL_TRIANGLES, mySphereIndices, GL_UNSIGNED_INT, 0);

		mvStack.pop();
	}
}

void lookAtCenter(int i,int d) {
	switch (i) {
	case 0://sun
		center = glm::vec3(0.0f, 0.0f, 0.0f);
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, 0.0, d*1.0));
		break;
	case 1://mercury
		center = glm::vec3(sin((float)(currentTime * 4.0/ RATE)) * 4.0f, 0.5f, (float)cos(currentTime * 4.0/RATE) * (4.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 2://venus
		center = glm::vec3(sin((float)(currentTime * 1.5 / RATE)) * 10.0f, -0.5f, (float)cos(currentTime *1.5 / RATE) *(10.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 3://earth
		center = glm::vec3(sin((float)(currentTime * 1.0 / RATE)) * 15.0f, 0.0f, (float)cos(currentTime * 1.0 / RATE) * (15.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 4://mars
		center = glm::vec3(sin((float)(currentTime * 0.5 / RATE)) * 23.0f, 2.0f, (float)cos(currentTime * 0.5 / RATE) * (23.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 5://jupiter
		center = glm::vec3(sin((float)(currentTime * 0.16 / RATE)) * 33.0f,4.0f, (float)cos(currentTime * 0.16 / RATE) * (33.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 6://saturn
		center = glm::vec3(sin((float)(currentTime * 0.3 / RATE)) * 40.0f, -8.0f, (float)cos(currentTime * 0.3 / RATE) * (40.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 7://uranus
		center = glm::vec3(sin((float)(currentTime * 0.1 / RATE)) * 45.0f, 8.0f, (float)cos(currentTime * 0.1 / RATE) * (45.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 8://neptune
		center = glm::vec3(sin((float)(currentTime *0.2 / RATE)) * 50.0f, 2.0f, (float)cos(currentTime * 0.2 / RATE) * (50.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	case 9://pluto
		center = glm::vec3(sin((float)(currentTime * 0.8 / RATE)) * 60.0f, 2.0f, (float)cos(currentTime *0.8 / RATE) * (60.0f + ellipseParamY));
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, d * 1.0, 0.0));
		break;
	default:
		break;
	}
}

void userViewMode(int mode) {
	switch (mode) {
	case 10: //autoplay
		cameraX = sin((float)currentTime / 8);
		cameraY = 0.0f;
		cameraZ = cos((float)currentTime / 8) * 50.0f;
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
		break;
	case 11: //look from upside
		cameraX = 0.0f;
		cameraY = 50.0f+ depthParam;
		cameraZ = 0.0f;
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, 0.0, 1.0));
		backgroundRotationDirection = glm::vec3(0.0, 0.0, 1.0);
		lookAtCenter(lookCenter,1);
		break;
	case 12: //look from downside
		cameraX = 0.0f;
		cameraY = -50.0f- depthParam;
		cameraZ = 0.0f;
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), center, glm::vec3(0.0, 0.0, -1.0));
		backgroundRotationDirection = glm::vec3(0.0, 0.0, 1.0);
		lookAtCenter(lookCenter,-1);
		break;
	default:
		cameraX = sin((float)currentTime / 8);
		cameraY = 0.0f;
		cameraZ = cos((float)currentTime / 8) * 50.0f;
		lookAtMat = glm::lookAt(glm::vec3(cameraX, cameraY, cameraZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
		break;
	}

}

void display(GLFWwindow* window) {

	backgroundRotationDirection = glm::vec3(0.0, 1.0, 0.0);

	//preprepare
	glClear(GL_DEPTH_BUFFER_BIT);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	glUseProgram(renderingProgram);
	mvLoc = glGetUniformLocation(renderingProgram, "mv_matrix");
	projLoc = glGetUniformLocation(renderingProgram, "proj_matrix");
	nLoc = glGetUniformLocation(renderingProgram, "norm_matrix");

	//lookat position and camera position
	userViewMode(viewMode);

	//view
	pMat = glm::perspective(1.0472f, aspect, 1.0f, 1000.0f);
	pMat = pMat * lookAtMat;
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));
	vMat = glm::translate(glm::mat4(1.0f), glm::vec3(-cameraX, -cameraY, -cameraZ));
	mvStack.push(vMat);

	//light
	currentLightPos= glm::vec3(0.0f, 0.0f, 0.0f);
	installLights(vMat);

	//half light of the texture
	glProgramUniform1i(renderingProgram, lightEnableLoc, 0);

	//----------------------  background sphere
	mvStack.push(mvStack.top());
	mvStack.top() *= rotate(glm::mat4(1.0f), (float)currentTime/10, backgroundRotationDirection);
	mvStack.top() *= scale(glm::mat4(1.0f), glm::vec3(200.0f, 200.0f, 200.0f));
	glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvStack.top()));
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
	glEnableVertexAttribArray(1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, backgroundTexture);
	glDisable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo[3]);
	glDrawElements(GL_TRIANGLES, mySphereIndices, GL_UNSIGNED_INT, 0);
	mvStack.pop();// pop the background

	//sun light
	glProgramUniform1i(renderingProgram, lightEnableLoc, 1);

	// ----------------------  sun
	mvStack.push(mvStack.top());
	mvStack.top() *= glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f));
	glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvStack.top()));
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
	glEnableVertexAttribArray(1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo[3]);
	glDrawElements(GL_TRIANGLES, mySphereIndices, GL_UNSIGNED_INT, 0);

#pragma region PlanetsCreation
	//enable light effect
	glProgramUniform1i(renderingProgram, lightEnableLoc, 2);


	//create planets
	//----------------------  mercury
	createPlanet(mercuryTexture, 4.0/RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		4.0f, 4.0f+ ellipseParamY, 0.5f, //xRotationRadius, yRotationRadius, height
		glm::vec3(0.8f, 0.8f, 0.8f), //scaleVector
		0.2f, glm::vec3(0.0, 0.0, -1.0));// tilt, tiltDirection

	//----------------------  venus
	createPlanet(venusTexture, 1.5 / RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		10.0f, 10.0f + ellipseParamY, -0.5f, //xRotationRadius, yRotationRadius, height
		glm::vec3(1.5f, 1.5f, 1.5f), //scaleVector
		0.41f, glm::vec3(0.0, 0.0, 1.0));// tilt, tiltDirection

	//----------------------  earth
	createPlanet(earthTexture, 1.0 / RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		15.0f, 15.0f + ellipseParamY, 0.0f, //xRotationRadius, yRotationRadius, height
		glm::vec3(1.7, 1.7f, 1.7f), //scaleVector
		0.41f, glm::vec3(0.0, 0.0, -1.0),// tilt, tiltDirection
		true,false);//pass to the moon
		//----------------------  moon
		createPlanet(moonTexture, 4.0 / RATE, // Texture, rotateSpeed
			0, glm::vec3(0.0, 0.0, 1.0),  // selfRotateRate, selfRotateDirection
			4.0f, 4.0f, 0.0f, //xRotationRadius, yRotationRadius, height
			glm::vec3(0.3f, 0.3f, 0.3f), //scaleVector
			0.0f,  glm::vec3(0.0, 0.0, 1.0),// tilt, tiltDirection
			false,true);//remove the tranlation of the earth
	//----------------------  mars
	createPlanet(marsTexture, 0.5 / RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		23.0f, 23.0f + ellipseParamY, 2.0f, //xRotationRadius, yRotationRadius, height
		glm::vec3(1.4f, 1.4f, 1.4f), //scaleVector
		0.35f, glm::vec3(0.0, 0.0, -1.0));// tilt, tiltDirection

	//----------------------  jupiter
	createPlanet(jupiterTexture, 0.16 / RATE, // Texture, rotateSpeed
		12, glm::vec3(0.0, -1.0, 0.0 ),  // selfRotateRate, selfRotateDirection
		33.0f, 33.0f + ellipseParamY, 4.0f, //xRotationRadius, yRotationRadius, height
		glm::vec3(4.5f, 4.5f, 4.5f), //scaleVector
		0.5f, glm::vec3(0.0, 0.0, -1.0));// tilt, tiltDirection

	//----------------------  saturn
	createPlanet(saturnTexture, 0.3 / RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		40.0f, 40.0f + ellipseParamY, -8.0f, //xRotationRadius, yRotationRadius, height
		glm::vec3(3.5f, 3.5f, 3.5f), //scaleVector
		0.5f, glm::vec3(0.0, 0.0, 1.0),// tilt, tiltDirection
		false, false, true);//don't pass or delete tranlation, create ring
	//----------------------  uranus
	createPlanet(uranusTexture, 0.1 / RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		45.0f, 45.0f + ellipseParamY, 8.0f, //xRotationRadius, yRotationRadius, height
		glm::vec3(2.5f, 2.5f, 2.5f), //scaleVector
		0.15f, glm::vec3(0.0, 0.0, -1.0),// tilt, tiltDirection
		false, false, true);//don't pass or delete tranlation, create ring

	//----------------------  neptune
	createPlanet(neptuneTexture, 0.2 / RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		50.0f, 50.0f + ellipseParamY, 2.0f, //xRotationRadius, yRotationRadius, height
		glm::vec3(2.0f, 2.0f, 2.0f), //scaleVector
		0.25f, glm::vec3(0.0, 0.0, 1.0));// tilt, tiltDirection

	//----------------------  pluto
	createPlanet(plutoTexture, 0.8 / RATE, // Texture, rotateSpeed
		6, glm::vec3(0.0, -1.0, 0.0),  // selfRotateRate, selfRotateDirection
		60.0f, 60.0f + ellipseParamY, 2.0f, //xRotationRadius, yRotationRadius, height
		glm::vec3(0.4f, 0.4f, 0.4f), //scaleVector
		0.25f, glm::vec3(0.0, 0.0, 1.0));// tilt, tiltDirection
#pragma endregion

	mvStack.pop();  // pop up the sun transition
	mvStack.pop();  // pop up the view matrix

}

void window_size_callback(GLFWwindow* win, int newWidth, int newHeight) {
	if (newHeight != 0) {
		aspect = (float)newWidth / (float)newHeight;
		glViewport(0, 0, newWidth, newHeight);
		pMat = glm::perspective(1.0472f, aspect, 0.1f, 1000.0f);
	}
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	switch (key)
	{
	case GLFW_KEY_W: //press w
		if (!(depthParam < -40.0f))
			depthParam -= 0.5f;
		break;
	case GLFW_KEY_S: //press s
		if (!(depthParam > 40.0f))
			depthParam += 0.5f;
		break;
	case GLFW_KEY_0://sun
		lookCenter = 0;
		break;
	case GLFW_KEY_1://mercury
		lookCenter = 1;
		break;
	case GLFW_KEY_2://venus
		lookCenter = 2;
		break;
	case GLFW_KEY_3://earth
		lookCenter = 3;
		break;
	case GLFW_KEY_4://mars
		lookCenter = 4;
		break;
	case GLFW_KEY_5://jupiter
		lookCenter = 5;
		break;
	case GLFW_KEY_6://saturn
		lookCenter = 6;
		break;
	case GLFW_KEY_7://uranus
		lookCenter = 7;
		break;
	case GLFW_KEY_8://neptune
		lookCenter = 8;
		break;
	case GLFW_KEY_9://pluto
		lookCenter = 9;
		break;
	case GLFW_KEY_U: //press u
		depthParam = 0.0f;
		lookCenter = 0;
		viewMode = 11;
		break;
	case GLFW_KEY_D: //press d
		depthParam = 0.0f;
		lookCenter = 0;
		viewMode = 12;
		break;
	default: // press any key to return
		viewMode = 10;
		break;
	}
}

int main(void) {
	if (!glfwInit()) { exit(EXIT_FAILURE); }
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	GLFWwindow* window = glfwCreateWindow(600, 600, "Project - Solar System", NULL, NULL);
	glfwMakeContextCurrent(window);
	if (glewInit() != GLEW_OK) { exit(EXIT_FAILURE); }
	glfwSwapInterval(1);

	glfwSetWindowSizeCallback(window, window_size_callback);

	init(window);
	while (!glfwWindowShouldClose(window)) {
		currentTime = glfwGetTime();
		glfwSetKeyCallback(window, key_callback);
		display(window);
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate();
	exit(EXIT_SUCCESS);
}